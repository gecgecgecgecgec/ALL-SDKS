#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announce_BuildingDamaged.Announce_BuildingDamaged_C.UserConstructionScript
struct AAnnounce_BuildingDamaged_C_UserConstructionScript_Params
{
};

// Function Announce_BuildingDamaged.Announce_BuildingDamaged_C.OnClientAnnouncementStart
struct AAnnounce_BuildingDamaged_C_OnClientAnnouncementStart_Params
{
};

// Function Announce_BuildingDamaged.Announce_BuildingDamaged_C.ExecuteUbergraph_Announce_BuildingDamaged
struct AAnnounce_BuildingDamaged_C_ExecuteUbergraph_Announce_BuildingDamaged_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
