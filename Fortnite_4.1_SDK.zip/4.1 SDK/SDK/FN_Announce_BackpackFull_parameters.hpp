#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announce_BackpackFull.Announce_BackpackFull_C.UserConstructionScript
struct AAnnounce_BackpackFull_C_UserConstructionScript_Params
{
};

// Function Announce_BackpackFull.Announce_BackpackFull_C.OnClientAnnouncementStart
struct AAnnounce_BackpackFull_C_OnClientAnnouncementStart_Params
{
};

// Function Announce_BackpackFull.Announce_BackpackFull_C.ExecuteUbergraph_Announce_BackpackFull
struct AAnnounce_BackpackFull_C_ExecuteUbergraph_Announce_BackpackFull_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
