#pragma once

// Fortnite (1.11) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// UserDefinedEnum AthenaDragDropAction.AthenaDragDropAction
enum class EAthenaDragDropAction : uint8_t
{
	NewEnumerator0                 = 0,
	NewEnumerator1                 = 1,
	NewEnumerator2                 = 2,
	AthenaDragDropAction_MAX       = 3
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
